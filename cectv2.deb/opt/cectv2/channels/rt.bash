#!/bin/bash
omxplayer https://liveproduseast.akamaized.net/btv/desktop/us_live.m3u8
#wait

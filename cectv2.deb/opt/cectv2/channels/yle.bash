#!/bin/bash
xmessage "yle"


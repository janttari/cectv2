#!/bin/bash
#lähetetään exit-signaali cectv:n komentotiedostoon
echo "exit"> /dev/shm/cectv2


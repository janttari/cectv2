#!/bin/bash
xmessage "svt1"
wait

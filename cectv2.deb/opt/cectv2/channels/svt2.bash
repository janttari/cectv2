#!/bin/bash
sleep 4
xmessage "svt2"

